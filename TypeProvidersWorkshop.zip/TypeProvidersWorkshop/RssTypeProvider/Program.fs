﻿[<EntryPoint>]
let main _ =
    printfn "RSS TYPE PROVIDERS WITH F#!"
    0
